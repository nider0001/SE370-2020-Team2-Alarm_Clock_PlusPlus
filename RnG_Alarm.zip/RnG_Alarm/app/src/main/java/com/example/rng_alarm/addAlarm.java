package com.example.rng_alarm;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputEditText;

public class addAlarm extends AppCompatActivity {
    private Button addButton = findViewById(R.id.buttonAdd);
    private TimePicker timePicker = findViewById(R.id.timePicker1);
    private TextView alarmTime = findViewById(R.id.displayAlarmTime);
    private TextView alarmNote = findViewById(R.id.noteAlarm);
    private String note;
    private int hr;
    private int min;

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addalarm);

        alarmTime.setText("--:--");

        addButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {

                //get time from the timePicker
                hr = timePicker.getHour();
                min = timePicker.getMinute();

                note = alarmNote.getText().toString();
                if(note.length() > 0 && note.length() <= 20)
                }
                }
                else{
                    System.out.println()
                }

                //creates a bundle to send back to main activity
                Bundle alarmSet = new Bundle();
                alarmSet.putInt("HOUR", hr);
                alarmSet.putInt("MIN", min);

                //creates intent to send back to main activity
                Intent returnIntent = new Intent();
                //adds the info form bundle into the intent
                returnIntent.putExtras(alarmSet);

                //sets the type of result when the activity is returned
                setResult(RESULT_OK, returnIntent);
                //finish the activity
                finish();
            }
        });

    }
}
